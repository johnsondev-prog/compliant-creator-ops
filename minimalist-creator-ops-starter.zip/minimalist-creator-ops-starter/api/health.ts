import { sendJson } from './_lib/http';

export default async function handler(_request: any, response: any) {
  sendJson(response, 200, {
    ok: true,
    service: 'minimalist-creator-ops-starter',
    timestamp: new Date().toISOString(),
  });
}
