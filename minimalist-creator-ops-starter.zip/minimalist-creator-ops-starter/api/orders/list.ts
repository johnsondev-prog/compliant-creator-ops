import { allowMethods, sendJson } from '../_lib/http';
import { listOrders } from '../_lib/storage';

export default async function handler(request: any, response: any) {
  const methodCheck = allowMethods(request.method, ['GET']);
  if (!methodCheck.ok) {
    return sendJson(response, methodCheck.status, methodCheck.body);
  }

  return sendJson(response, 200, {
    orders: listOrders(),
  });
}
