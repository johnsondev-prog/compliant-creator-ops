import crypto from 'node:crypto';
import { z } from 'zod';
import { allowMethods, readJsonBody, sendJson } from '../_lib/http';
import { quotePartnerFulfillment } from '../_lib/providers';
import { createOrder } from '../_lib/storage';

const payloadSchema = z.object({
  email: z.string().email(),
  product: z.string().min(2),
  amountNgn: z.number().positive(),
});

export default async function handler(request: any, response: any) {
  const methodCheck = allowMethods(request.method, ['POST']);
  if (!methodCheck.ok) {
    return sendJson(response, methodCheck.status, methodCheck.body);
  }

  try {
    const payload = payloadSchema.parse(await readJsonBody(request));
    const quote = await quotePartnerFulfillment({ product: payload.product });
    const order = createOrder({
      id: crypto.randomUUID(),
      email: payload.email,
      product: payload.product,
      amountNgn: payload.amountNgn,
      status: 'pending',
      provider: quote.provider,
      metadata: { notes: quote.notes },
    });

    return sendJson(response, 200, { ok: true, order, quote });
  } catch (error) {
    return sendJson(response, 400, {
      error: error instanceof Error ? error.message : 'Could not create order',
    });
  }
}
