create table if not exists users (
  id uuid primary key,
  clerk_user_id text unique not null,
  email text unique not null,
  role text not null default 'customer',
  created_at timestamptz not null default now()
);

create table if not exists orders (
  id uuid primary key,
  user_id uuid references users(id),
  email text not null,
  product text not null,
  amount_ngn integer not null,
  status text not null,
  provider text not null,
  payment_reference text unique,
  metadata jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists payments (
  id uuid primary key,
  order_id uuid references orders(id) not null,
  provider text not null default 'paystack',
  reference text unique not null,
  amount_ngn integer not null,
  currency text not null default 'NGN',
  status text not null,
  raw_payload jsonb,
  created_at timestamptz not null default now()
);

create index if not exists idx_orders_status on orders(status);
create index if not exists idx_orders_created_at on orders(created_at desc);
create index if not exists idx_payments_reference on payments(reference);
